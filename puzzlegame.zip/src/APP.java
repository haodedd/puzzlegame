import ui.GameJFrame;
import ui.LoginJFrame;
import ui.RegisteJFrame;

public class APP {
    public static void main(String[] args) {
       // new RegisteJFrame();
        new GameJFrame();
       // new LoginJFrame();
    }
}
